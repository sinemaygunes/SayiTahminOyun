import java.util.Random;
import java.util.Scanner;

public class NumberGuessingGame {

    public static void main(String[] args) {
        Random random = new Random();
        int randomNumber = random.nextInt(100) + 1; 
        Scanner scanner = new Scanner(System.in);
        
        int maxDeneme = 3; 
        
        System.out.println("1-100 arası bir sayı tahmin edin. 3 hakkınız var.");
        
        playGame(scanner, randomNumber, maxDeneme);
    }

    public static void playGame(Scanner scanner, int randomNumber, int maxDeneme) {
        int guess = 0; 
        
        for (int deneme = 0; deneme < maxDeneme; deneme++) {
            guess = getUserGuess(scanner);
           
            if (guess == randomNumber) {
                System.out.println("Tebrikler, doğru tahmin ettiniz!");
                return; 
            } else {
                System.out.println("Yanlış tahmin!");
            }

            
            int remainingDeneme = maxDeneme - deneme - 1; 
            if (remainingDeneme > 0) {
                System.out.println("Kalan hakkınız: " + remainingDeneme);
            } else {
               
                System.out.println("Hakkınız kalmadı. Doğru sayı: " + randomNumber);
            }
        }
    }

    public static int getUserGuess(Scanner scanner) {
        System.out.print("Tahmininiz: ");
        return scanner.nextInt(); 
    }
}


